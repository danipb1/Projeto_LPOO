package projetinho;

public class Aluno extends Pessoa {

}
