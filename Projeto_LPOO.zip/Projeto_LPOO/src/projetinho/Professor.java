package projetinho;

public class Professor extends Pessoa {

}
